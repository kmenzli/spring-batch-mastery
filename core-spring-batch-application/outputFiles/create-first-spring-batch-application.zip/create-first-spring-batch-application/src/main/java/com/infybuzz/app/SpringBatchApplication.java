package com.infybuzz.app;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.Arrays;

@SpringBootApplication
@EnableBatchProcessing
@ComponentScan({"com.infybuzz.config", "com.infybuzz.service", "com.infybuzz.listener", "com.infybuzz.chunk","com.infybuzz.controller" })
@EnableAsync
//@EnableScheduling
public class SpringBatchApplication {

	public static void main(String[] args) {
		Arrays.stream(args).toList().forEach(System.out::println);
		SpringApplication.run(SpringBatchApplication.class, args);
	}

}
