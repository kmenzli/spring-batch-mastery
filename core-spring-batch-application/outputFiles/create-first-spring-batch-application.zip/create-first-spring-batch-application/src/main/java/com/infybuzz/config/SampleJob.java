package com.infybuzz.config;

import com.infybuzz.chunk.*;
import com.infybuzz.listener.FirstListener;
import com.infybuzz.listener.FirstStepListener;
import com.infybuzz.listener.SkipListener;
import com.infybuzz.model.StudentCsv;
import com.infybuzz.model.StudentJdbc;
import com.infybuzz.model.StudentJson;
import com.infybuzz.model.StudentXml;
import com.infybuzz.model.entity.postgres.Student;
import com.infybuzz.service.SecondTasklet;
import com.infybuzz.service.StudentService;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.skip.AlwaysSkipItemSkipPolicy;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.adapter.ItemWriterAdapter;
import org.springframework.batch.item.database.*;
import org.springframework.batch.item.file.*;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FlatFileFormatException;
import org.springframework.batch.item.json.JacksonJsonObjectMarshaller;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonFileItemWriter;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.Writer;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Configuration
public class SampleJob {
    @Autowired
    JobBuilderFactory jobBuilderFactory;
    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    SecondTasklet secondTasklet;

    @Autowired
    FirstListener firstListener;

    @Autowired
    FirstStepListener firstStepListener;

    @Autowired
    FirstItemProcessor firstItemProcessor;

    @Autowired
    SkipListener skipListener;

    @Autowired
    ConvertorItemProcessor convertorItemProcessor;
    @Autowired
    FirstItemReader firstItemReader;
    @Autowired
    FirstItemWriter firstItemWriter;

    @Autowired
    StudentService studentService;

    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Autowired
    @Qualifier("businessDataSource")
    private DataSource businessDataSource;
    @Autowired
    @Qualifier("sourceBusinessDataSource")
    private DataSource sourceBusinessDataSource;

    @Autowired
    @Qualifier("mysqlEntityManagerFactory")
    private EntityManagerFactory mysqlEntityManagerFactory;

    @Autowired
    @Qualifier("postgresEntityManagerFactory")
    private EntityManagerFactory postgresEntityManagerFactory;

    @Autowired
    private MigrationItemProcessor migrationItemProcessor;

    @Autowired
    private JpaTransactionManager jpaTransactionManager;

    /**
     * @Bean public Job firstJob() {
     * return jobBuilderFactory.get("firstJob")
     * .incrementer(new RunIdIncrementer())
     * .start(firstStep())
     * .listener(firstListener)
     * .next(secondStep())
     * .build();
     * }
     */
    /**
    @Bean
    public Job secondJob() {
        return jobBuilderFactory.get("ChunkJob")
                .incrementer(new RunIdIncrementer())
                .start(firstChunkStep())
                .next(secondStep())
                .build();
    }

    @Bean
    private Step firstChunkStep() {
        return stepBuilderFactory.get("ChunkStep")
                .<StudentCsv, StudentJson>chunk(3)
                .reader(flatFileItemReader(null))
                //.reader(jsonItemReader(null))
                //.reader(xmlItemReader(null))
                //.reader(jdbcCursorItemReader(null))
                //.reader(itemReaderAdapter())

                //.processor(firstItemProcessor)
                .processor(convertorItemProcessor)
                //.writer(firstItemWriter)
                //.writer(flatFileItemWriter(null))
                .writer(jsonFileItemWriter(null))
                //.writer(staxEventItemWriter(null))
                //.writer(jdbcBatchItemWriter())
                //.writer(jdbcBatchPrepareStatementItemWriter())
                //.writer(itemWriterAdapter())
                .faultTolerant()
                .skip(FlatFileParseException.class)
                .skip(NullPointerException.class)
                .skipLimit(100)
                //.skipPolicy(new AlwaysSkipItemSkipPolicy())
                .retryLimit(2)
                .retry(Throwable.class)
                .listener(skipListener)
                .build();
    }
     */
    @Bean
    public Job migrationJob() {
        return jobBuilderFactory.get("MigrationJob")
                .incrementer(new RunIdIncrementer())
                .start(migrationChunkStep())
                .next(migrationChunkStep())
                .build();
    }
    private Step migrationChunkStep() {
        return stepBuilderFactory.get("ChunkStep")
                .<Student, com.infybuzz.model.entity.mysql.Student>chunk(5)
                .reader(jpaCursorItemReader())
                .processor(migrationItemProcessor)
                .writer(jpaItemWriter())
                .faultTolerant()
                .skip(FlatFileParseException.class)
                .skip(NullPointerException.class)
                .skipLimit(100)
                //.skipPolicy(new AlwaysSkipItemSkipPolicy())
                .retryLimit(2)
                .retry(Throwable.class)
                .listener(skipListener)
                .transactionManager(jpaTransactionManager)
                .build();
    }


    private Step firstStep() {
        return stepBuilderFactory.get("firstStep")
                .tasklet(firstTask())
                .listener(firstStepListener)
                .build();
    }

    private Step secondStep() {
        return stepBuilderFactory.get("secondStep")
                .tasklet(secondTasklet)
                .build();
    }


    private Tasklet firstTask() {
        return new Tasklet() {

            @Override
            public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
                System.out.println("My First Tasklet Step");
                System.out.println("Step ExecutionContext" + chunkContext.getStepContext().getStepExecutionContext());
                return RepeatStatus.FINISHED;
            }

        };

    }

    /* 1er manière de faire un FlatFileItemReader
    @Bean
    @StepScope
    public FlatFileItemReader<StudentCsv> flatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        FlatFileItemReader<StudentCsv> itemReader = new FlatFileItemReader<>();
        itemReader.setResource(fileSystemResource);
        itemReader.setLineMapper(new DefaultLineMapper<StudentCsv>() {
            {
                setLineTokenizer(new DelimitedLineTokenizer() {
                    {
                        setNames("ID","First Name","Last Name","Email");
                        setDelimiter("|");
                    }
                });
                setFieldSetMapper(new BeanWrapperFieldSetMapper<StudentCsv>(){
                    {
                        setTargetType(StudentCsv.class);
                    }
                });
            }
        });
        itemReader.setLinesToSkip(1);
        return itemReader;
    }
    */


    @Bean
    @StepScope
    public FlatFileItemReader<StudentCsv> flatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        FlatFileItemReader<StudentCsv> itemReader = new FlatFileItemReader<>();
        itemReader.setResource(fileSystemResource);
        // Creation de l'objet LineMapper
        DefaultLineMapper<StudentCsv> defaultLineMapper = new DefaultLineMapper<StudentCsv>();

        // Creation d'un Tokeenizer
        DelimitedLineTokenizer delimitedLineTokenizer = new DelimitedLineTokenizer();
        delimitedLineTokenizer.setNames("ID", "First Name", "Last Name", "Email");
        delimitedLineTokenizer.setDelimiter("|");

        // Creation d'un Bean Mapper de type BeanWrapperFieldSetMapper
        BeanWrapperFieldSetMapper<StudentCsv> studentCsvBeanWrapperFieldSetMapper = new BeanWrapperFieldSetMapper<StudentCsv>();
        studentCsvBeanWrapperFieldSetMapper.setTargetType(StudentCsv.class);

        // attacher tout les objet créer à notre LneMapper
        defaultLineMapper.setLineTokenizer(delimitedLineTokenizer);
        defaultLineMapper.setFieldSetMapper(studentCsvBeanWrapperFieldSetMapper);

        // Attacher le LineMapper
        itemReader.setLineMapper(defaultLineMapper);
        itemReader.setLinesToSkip(1);
        return itemReader;
    }

    @Bean
    @StepScope
    public JsonItemReader<StudentJson> jsonItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        JsonItemReader<StudentJson> jsonJsonItemReader = new JsonItemReader<StudentJson>();
        jsonJsonItemReader.setResource(fileSystemResource);
        jsonJsonItemReader.setJsonObjectReader(new JacksonJsonObjectReader<>(StudentJson.class));
        return jsonJsonItemReader;
    }

    @Bean
    @StepScope
    public StaxEventItemReader<StudentXml> xmlItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        StaxEventItemReader<StudentXml> xmlStaxEventItemReader = new StaxEventItemReader<StudentXml>();

        xmlStaxEventItemReader.setResource(fileSystemResource);
        xmlStaxEventItemReader.setFragmentRootElementName("student");
        xmlStaxEventItemReader.setUnmarshaller(new Jaxb2Marshaller() {
            {
                setClassesToBeBound(StudentXml.class);
            }
        });

        return xmlStaxEventItemReader;
    }

    @Bean
    @StepScope
    public JdbcCursorItemReader<StudentJdbc> jdbcCursorItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        JdbcCursorItemReader<StudentJdbc> itemReader = new JdbcCursorItemReader<StudentJdbc>();

        itemReader.setDataSource(businessDataSource);
        itemReader.setSql(
                "SELECT id, first_name as firstName, last_name as lastName, email FROM student"
        );
        itemReader.setRowMapper(new BeanPropertyRowMapper<>() {
            {
                setMappedClass(StudentJdbc.class);
            }
        });
        return itemReader;
    }

    /*
        public ItemReaderAdapter<StudentResponse> itemReaderAdapter() {
            ItemReaderAdapter<StudentResponse> itemReaderAdapter = new ItemReaderAdapter<StudentResponse>();
            itemReaderAdapter.setTargetMethod("getStudent");
            itemReaderAdapter.setTargetObject(studentService);
            itemReaderAdapter.setArguments(new Object[] {1L, "Khemais"});
            return itemReaderAdapter;
        }
    */
    @Bean
    @StepScope
    public FlatFileItemWriter<StudentJdbc> flatFileItemWriter(@Value("#{jobParameters['outputFile']}") FileSystemResource fileSystemResource) {
        FlatFileItemWriter<StudentJdbc> flatFileItemWriter = new FlatFileItemWriter<StudentJdbc>();

        flatFileItemWriter.setResource(fileSystemResource);
        //--- Créer le Header
        flatFileItemWriter.setHeaderCallback(new FlatFileHeaderCallback() {
            @Override
            public void writeHeader(Writer writer) throws IOException {
                writer.write("ID, first name, Last Name, Email");
            }
        });
        //--- Extraire les données à ecrire
        flatFileItemWriter.setLineAggregator(new DelimitedLineAggregator<>() {
            {
                setDelimiter("|");
                setFieldExtractor(new BeanWrapperFieldExtractor<StudentJdbc>() {
                    {
                        setNames(new String[]{"id", "firstName", "lastName", "email"});
                    }
                });
            }

        });
        //-- Créer le footer
        flatFileItemWriter.setFooterCallback(new FlatFileFooterCallback() {

            @Override
            public void writeFooter(Writer writer) throws IOException {
                writer.write(" Traiement fait @ " + System.currentTimeMillis());
            }
        });
        return flatFileItemWriter;
    }

    @Bean
    @StepScope
    public JsonFileItemWriter<StudentJson> jsonFileItemWriter(@Value("#{jobParameters['outputFile']}") FileSystemResource fileSystemResource) {
        JsonFileItemWriter<StudentJson> jsonFileItemWriter = new JsonFileItemWriter<StudentJson>(fileSystemResource, new JacksonJsonObjectMarshaller<StudentJson>()) {
            @Override
            public String doWrite(List<? extends StudentJson> items) {
                items.stream().forEach(i -> {
                    if (i.getId() ==1 ) {
                        System.out.println("==========> Writer "+i.getId());
                        throw new NullPointerException(" From Writer");
                    }
                });
                return super.doWrite(items);
            }
        };
        return jsonFileItemWriter;
    }

    @Bean
    @StepScope
    public StaxEventItemWriter<StudentJdbc> staxEventItemWriter(@Value("#{jobParameters['outputFile']}") FileSystemResource fileSystemResource) {
        StaxEventItemWriter<StudentJdbc> staxEventItemWriter = new StaxEventItemWriter<StudentJdbc>();
        staxEventItemWriter.setResource(fileSystemResource);
        //--- spécifier la balise parente de tout les elements
        staxEventItemWriter.setRootTagName("students");
        //--- Faut préciser que nous faisons du Marsheling  : convertire un Objet en XML
        staxEventItemWriter.setMarshaller(new Jaxb2Marshaller(){
            {
                setClassesToBeBound(StudentJdbc.class);
            }
        });
        return staxEventItemWriter;
    }

    @Bean
    @StepScope
    public JdbcBatchItemWriter<StudentCsv> jdbcBatchItemWriter () {
        JdbcBatchItemWriter<StudentCsv> jdbcJdbcBatchItemWriter = new JdbcBatchItemWriter<StudentCsv>();
        jdbcJdbcBatchItemWriter.setDataSource(businessDataSource);
        jdbcJdbcBatchItemWriter.setSql(
                "INSERT into student (id, first_name, last_name, email) VALUES (:id, :firstName, :lastName, :email)"
        );
        jdbcJdbcBatchItemWriter.setItemSqlParameterSourceProvider(
                new BeanPropertyItemSqlParameterSourceProvider<StudentCsv>());
        return jdbcJdbcBatchItemWriter;
    }

    @Bean
    @StepScope
    public JdbcBatchItemWriter<StudentCsv> jdbcBatchPrepareStatementItemWriter () {
        JdbcBatchItemWriter<StudentCsv> jdbcJdbcBatchItemWriter = new JdbcBatchItemWriter<StudentCsv>();
        jdbcJdbcBatchItemWriter.setDataSource(businessDataSource);
        jdbcJdbcBatchItemWriter.setSql(
                "INSERT into student (id, first_name, last_name, email) VALUES (?, ?, ?, ?)"
        );
        jdbcJdbcBatchItemWriter.setItemPreparedStatementSetter(new ItemPreparedStatementSetter<StudentCsv>() {
            @Override
            public void setValues(StudentCsv item, PreparedStatement ps) throws SQLException {
                ps.setLong(1, item.getId());
                ps.setString(2, item.getFirstName());
                ps.setString(3, item.getLastName());
                ps.setString(4, item.getEmail());
            }
        });
        return jdbcJdbcBatchItemWriter;
    }

    @Bean
    @StepScope
    public ItemWriterAdapter<StudentCsv> itemWriterAdapter () {
        ItemWriterAdapter<StudentCsv> itemWriterAdapter = new ItemWriterAdapter<StudentCsv>();
        itemWriterAdapter.setTargetMethod("create");
        itemWriterAdapter.setTargetObject(studentService);
        return itemWriterAdapter;

    }

    @Bean
    @StepScope
    public JpaCursorItemReader<Student> jpaCursorItemReader () {
        JpaCursorItemReader<Student> jpaCursorItemReader = new JpaCursorItemReader<Student>();
        jpaCursorItemReader.setEntityManagerFactory(postgresEntityManagerFactory);
        jpaCursorItemReader.setQueryString("From Student");
        return jpaCursorItemReader;
    }

    @Bean
    @StepScope
    public JpaItemWriter<com.infybuzz.model.entity.mysql.Student> jpaItemWriter (){
        JpaItemWriter<com.infybuzz.model.entity.mysql.Student> jpaItemWriter =
                new JpaItemWriter<com.infybuzz.model.entity.mysql.Student>();
        jpaItemWriter.setEntityManagerFactory(mysqlEntityManagerFactory);
        return jpaItemWriter;
    }
    /*
    private Tasklet secondTask() {
        return new Tasklet(){

            @Override
            public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
                System.out.println("My Second Tasklet Step");
                return RepeatStatus.FINISHED;
            }
        };

    }
    */
}
