package com.infybuzz.service;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class SecondJobScheduler {

    @Autowired
    JobLauncher jobLauncher;
    @Autowired
    Job secondJob;

    //@Scheduled(cron = "0 0/1 * 1/1 * ?")
    public void secondJobScheduler() {
        try {

            Map<String, JobParameter> map = new HashMap<>();
            map.put("currentTime", new JobParameter(System.currentTimeMillis()));

            JobParameters params = new JobParameters(map);

            JobExecution jobExecution = jobLauncher.run(secondJob, params);

            System.out.println("JobExecution ID = " + jobExecution.getJobId());
        } catch (Exception e) {
            System.out.println("Une Exception est lancée");
        }

    }
}
