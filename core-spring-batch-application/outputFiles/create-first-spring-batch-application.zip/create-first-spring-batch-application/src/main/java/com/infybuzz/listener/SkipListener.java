package com.infybuzz.listener;

import com.infybuzz.model.StudentCsv;
import com.infybuzz.model.StudentJson;
import org.springframework.batch.core.annotation.OnSkipInProcess;
import org.springframework.batch.core.annotation.OnSkipInRead;
import org.springframework.batch.core.annotation.OnSkipInWrite;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;

@Component
public class SkipListener {
    @OnSkipInRead
    public void skipOnRead(Throwable th) {

        if (th instanceof FlatFileParseException) {
            createFile("/Users/menzli.khemais/WIP/workspace/kmenzli/back-office/udemy/batch/create-first-spring-batch-application/ChunkJob/ChunkStep/reader/skipInRead.txt",
                    ((FlatFileParseException) th).getInput());
        }
    }

    @OnSkipInProcess
    public void skipOnProcss(StudentCsv item, Throwable th) {

            createFile("/Users/menzli.khemais/WIP/workspace/kmenzli/back-office/udemy/batch/create-first-spring-batch-application/ChunkJob/ChunkStep/processor/skipInProcess.txt",
                    item.toString());

    }

    @OnSkipInWrite
    public void skipOnWriter(StudentJson item, Throwable th) {

        createFile("/Users/menzli.khemais/WIP/workspace/kmenzli/back-office/udemy/batch/create-first-spring-batch-application/ChunkJob/ChunkStep/writer/skipInWriter.txt",
                item.toString());

    }

    public void createFile(String pathFile, String data) {
        try (FileWriter fw = new FileWriter(new File(pathFile), true)) {
            fw.write(data + "\n");
        } catch (Exception e) {

        }
    }
}
