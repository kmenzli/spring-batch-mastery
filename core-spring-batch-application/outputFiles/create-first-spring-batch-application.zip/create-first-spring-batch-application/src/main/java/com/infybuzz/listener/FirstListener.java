package com.infybuzz.listener;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameter;
import org.springframework.stereotype.Component;

@Component
public class FirstListener implements JobExecutionListener {
    @Override
    public void beforeJob(JobExecution jobExecution) {
        System.out.println("Before Job" + jobExecution.getJobInstance().getJobName());
            System.out.println("Before Job Parameters" + jobExecution.getJobParameters());
        System.out.println("Before Job Exécution Context" + jobExecution.getExecutionContext());
        jobExecution.getExecutionContext().put("modif1", "MaValeur");
        jobExecution.getExecutionContext().put("modif2", "MaValeur2");
        jobExecution.getExecutionContext().put("modif3", "MaValeur3");

        jobExecution.getJobParameters().getParameters().put("BLA", new JobParameter("BLA"));
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        System.out.println("After Job " + jobExecution.getJobInstance().getJobName());
        System.out.println("After Job Parameters " + jobExecution.getJobParameters());
        System.out.println("After Job Exécution Context " + jobExecution.getExecutionContext());
    }
}
