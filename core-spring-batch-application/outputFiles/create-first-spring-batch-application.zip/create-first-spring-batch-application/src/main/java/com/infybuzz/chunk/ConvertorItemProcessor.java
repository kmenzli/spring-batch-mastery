package com.infybuzz.chunk;

import com.infybuzz.model.StudentCsv;
import com.infybuzz.model.StudentJdbc;
import com.infybuzz.model.StudentJson;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ConvertorItemProcessor implements ItemProcessor<StudentCsv, StudentJson> {
    @Override
    public StudentJson process(StudentCsv item) throws Exception {
        System.out.println("Covertor Processor in action ...");
        if (item.getId() == 3) {
            System.out.println("==========> Processor "+item.getId());
            throw new NullPointerException("Tnaket");
        }
        StudentJson studentJson = new StudentJson();
        studentJson.setId(item.getId());
        studentJson.setEmail(item.getEmail());
        studentJson.setFirstName(item.getFirstName());
        studentJson.setFirstName(item.getFirstName());
        return studentJson;
    }
}
