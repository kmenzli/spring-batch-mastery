package com.infybuzz.service;

import com.infybuzz.request.JobRequest;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class JobService {
    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job firstJob;

    @Autowired
    Job secondJob;

    JobExecution jobExecution = null;
    @Async
    public void callJob(String jobName, List<JobRequest> paramList) {
        try {

            Map<String, JobParameter> map = new HashMap<>();
            map.put("currentTime", new JobParameter(System.currentTimeMillis()));
            paramList.stream().forEach(j -> {
                map.put(j.getParamKey(), new JobParameter(j.getParamValue()));
            });
            JobParameters params = new JobParameters(map);

            if (jobName.equalsIgnoreCase("firstJob")) {
                jobExecution =jobLauncher.run(firstJob, params);
            } else if (jobName.equalsIgnoreCase("secondJob")) {
                jobExecution =jobLauncher.run(secondJob, params);
            }
            System.out.println("JobExecution ID = "+jobExecution.getJobId());
        } catch (Exception e) {
            System.out.println("Une Exception est lancée");
        }
    }
}
