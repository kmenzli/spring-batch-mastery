package com.infybuzz.chunk;

import com.infybuzz.model.StudentJson;
import com.infybuzz.model.entity.postgres.Student;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class MigrationItemProcessor implements ItemProcessor<Student, com.infybuzz.model.entity.mysql.Student> {

    @Override
    public com.infybuzz.model.entity.mysql.Student process(Student item) throws Exception {
        System.out.println("Inside MigrationItemProcessor ....");
        com.infybuzz.model.entity.mysql.Student studentMysql = new com.infybuzz.model.entity.mysql.Student();
        studentMysql.setId(item.getId());
        studentMysql.setEmail(item.getEmail());
        studentMysql.setFirstName(item.getFirstName());
        studentMysql.setFirstName(item.getFirstName());
        studentMysql.setDeptId(item.getDeptId());
        studentMysql.setActive(Boolean.valueOf(item.getIsActive()));
        return studentMysql;
    }
}
