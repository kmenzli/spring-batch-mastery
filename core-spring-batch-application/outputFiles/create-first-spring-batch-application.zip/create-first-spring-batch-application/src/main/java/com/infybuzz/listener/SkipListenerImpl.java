package com.infybuzz.listener;

import com.infybuzz.model.StudentCsv;
import com.infybuzz.model.StudentJson;
import org.springframework.batch.core.SkipListener;
import org.springframework.stereotype.Component;

@Component
public class SkipListenerImpl implements SkipListener<StudentCsv, StudentJson> {
    @Override
    public void onSkipInRead(Throwable t) {

    }
    @Override
    public void onSkipInWrite(StudentJson item, Throwable t) {

    }
    @Override
    public void onSkipInProcess(StudentCsv item, Throwable t) {

    }
}
