INSERT INTO student (first_name, last_name,email) VALUES ('khmeias','MENZLI', 'a@gmail.com');
INSERT INTO student (first_name, last_name,email) VALUES ('abdo','MENZLI', 'b@gmail.com');
INSERT INTO student (first_name, last_name,email) VALUES ('youssef','MENZLI', 'c@gmail.com');
INSERT INTO student (first_name, last_name,email) VALUES ('assil','MENZLI', 'd@gmail.com');
INSERT INTO student (first_name, last_name,email) VALUES ('osswa','MENZLI', 'e@gmail.com');
INSERT INTO student (first_name, last_name,email) VALUES ('neermine','MENZLI', 'f@gmail.com');